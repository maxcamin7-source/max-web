import React, { useState } from 'react';
import { Mail, Phone, Linkedin, MapPin, Briefcase, TrendingUp, Compass } from 'lucide-react';
import { TabType } from './types';
import AboutTab from './components/AboutTab';
import ExperienceTab from './components/ExperienceTab';
import VenturesTab from './components/VenturesTab';
import AspirationsTab from './components/AspirationsTab';
import Footer from './components/Footer';
import ChatBot from './components/ChatBot';
import ConnectSection from './components/ConnectSection';
import { HEADSHOT } from './ImagesData';

const LINKEDIN_URL = "https://www.linkedin.com/in/max-camin";
const EMAIL_ADDRESS = "maxcamin32@gmail.com";
const PHONE_NUMBER = "832.802.3281";

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabType>(TabType.ASPIRATIONS);

  const tabs = [TabType.ABOUT, TabType.EXPERIENCE, TabType.VENTURES, TabType.ASPIRATIONS];

  return (
    <div className="min-h-screen flex flex-col items-center py-8 px-4 sm:px-12 relative">
      <div className="max-w-[1200px] w-full space-y-10">
        {/* Header Section */}
        <header className="flex flex-col md:flex-row items-center md:items-start gap-10">
          <div className="relative flex-shrink-0 bg-white rounded-2xl shadow-md border border-gray-100 p-2 overflow-hidden flex items-center justify-center min-w-[192px] min-h-[192px] max-w-[256px]">
            <img 
              src={HEADSHOT.startsWith('PASTE') ? "https://picsum.photos/seed/max/240/240" : HEADSHOT} 
              alt="Max Camin" 
              className="w-full h-auto max-h-64 object-contain rounded-xl"
            />
          </div>
          
          <div className="flex-1 space-y-6 w-full text-center md:text-left">
            <div>
              <h1 className="text-6xl font-bold text-slate-900 tracking-tight">Max Camin</h1>
              <div className="flex items-center justify-center md:justify-start gap-4 mt-4">
                <div className="hidden sm:block h-0.5 w-10 bg-amber-400"></div>
                <p className="text-lg font-bold text-slate-700 uppercase tracking-[0.15em]">
                  Finance & Marketing Student | Aspiring Wealth Manager
                </p>
              </div>
            </div>

            <div className="flex flex-wrap justify-center md:justify-start gap-x-10 gap-y-4 text-base text-slate-500 font-medium">
              <div className="flex items-center gap-2.5 whitespace-nowrap">
                <MapPin size={18} className="text-slate-400" />
                <span>Waco, TX / Kingwood, TX</span>
              </div>
              <div className="flex items-center gap-2.5 whitespace-nowrap">
                <Mail size={18} className="text-slate-400" />
                <a href={`mailto:${EMAIL_ADDRESS}`} className="hover:text-emerald-700 transition-colors">{EMAIL_ADDRESS}</a>
              </div>
              <div className="flex items-center gap-2.5 whitespace-nowrap">
                <Phone size={18} className="text-slate-400" />
                <span>{PHONE_NUMBER}</span>
              </div>
              <div className="flex items-center gap-2.5 whitespace-nowrap">
                <Linkedin size={18} className="text-slate-400" />
                <a href={LINKEDIN_URL} target="_blank" rel="noopener noreferrer" className="hover:text-emerald-700 transition-colors">LinkedIn</a>
              </div>
            </div>

            <p className="text-lg leading-relaxed text-slate-600 max-w-4xl mx-auto md:mx-0">
              Finance and Marketing double major with a passion for financial analysis and client service, leveraging strong decision-making skills to deliver data-driven results. Experienced in assisting advisors with relationship management and account servicing in a professional wealth management setting. Highly self-motivated, adaptable, and driven.
            </p>
          </div>
        </header>

        {/* Navigation Tabs */}
        <nav className="border-b-2 border-gray-100">
          <ul className="flex flex-wrap -mb-[2px] text-sm font-bold uppercase tracking-widest">
            {tabs.map((tab) => (
              <li key={tab} className="mr-12">
                <button
                  onClick={() => setActiveTab(tab)}
                  className={`inline-flex items-center gap-3 py-6 px-2 border-b-4 transition-colors ${
                    activeTab === tab 
                      ? 'border-emerald-700 text-emerald-700' 
                      : 'border-transparent text-slate-400 hover:text-slate-600'
                  }`}
                >
                  {tab === TabType.ABOUT && <Compass size={18} />}
                  {tab === TabType.EXPERIENCE && <Briefcase size={18} />}
                  {tab === TabType.VENTURES && <TrendingUp size={18} />}
                  {tab === TabType.ASPIRATIONS && <Compass size={18} />}
                  {tab}
                </button>
              </li>
            ))}
          </ul>
        </nav>

        {/* Content Section */}
        <main className="min-h-[700px] pb-0">
          {activeTab === TabType.ABOUT && <AboutTab />}
          {activeTab === TabType.EXPERIENCE && <ExperienceTab />}
          {activeTab === TabType.VENTURES && <VenturesTab />}
          {activeTab === TabType.ASPIRATIONS && <AspirationsTab />}
        </main>

        <div id="connect-section">
          <ConnectSection />
        </div>

        <Footer />
      </div>

      <ChatBot />
    </div>
  );
};

export default App;