
export enum TabType {
  ABOUT = 'About',
  EXPERIENCE = 'Experience',
  VENTURES = 'Ventures',
  ASPIRATIONS = 'Aspirations'
}

export interface ExperienceItem {
  title: string;
  organization: string;
  location?: string;
  period: string;
  description: string[];
  logo?: string;
}

export interface PassionItem {
  icon: string;
  name: string;
  description: string;
}

export interface LanguageItem {
  name: string;
  level: string;
  percentage: number;
}
